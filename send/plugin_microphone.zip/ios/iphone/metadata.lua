local metadata =
{
	plugin =
	{
		format = 'staticLibrary',
		staticLibs = { 'plugin_library', },
		frameworks = {},
		frameworksOptional = {},
		-- usesSwift = true,
	},
}

return metadata
